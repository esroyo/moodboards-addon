updateMenu();

window.__background = true;

// browser.runtime.onMessage.addListener(function (data, sender) {
//     console.log(data);
// });
