# moodboards-addon
Make moodboards quickly by collecting images through the Firefox contextual menu

**This is alpha software, please don't use it as a production tool.**

## Usage
The addon adds new icon in the toolbar which gives acces to the Moodboards tab.

To add images to a moodboard, you'll find an option in the right click contextual menu (similar to "Save image as...") called "Add Image to moodboard".

The creation of moodboards is handled from that same contextual menu.

The moodboard editor is quite limited, just click an image to bring it to the front and press `delete` key while it is selected to remove it.
